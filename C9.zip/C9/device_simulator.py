"""
A simple MQTT device simulator that publishes JSON readings periodically.

Usage:
    python device_simulator.py --device-id my-device-1 --interval 5
"""
import argparse
import json
import time
import random
import paho.mqtt.client as mqtt

BROKER = "localhost"
PORT = 1883
TOPIC_TEMPLATE = "healthcare/device/{device_id}/data"


def make_reading(device_id):
    # random realistic ranges with some variation
    hr = round(random.gauss(75, 10), 1)
    spo2 = round(random.gauss(97, 1.5), 1)
    temp = round(random.gauss(36.7, 0.7), 1)
    sys = round(random.gauss(120, 12), 1)
    dia = round(sys * random.uniform(0.5, 0.8), 1)
    cough = 1 if random.random() < 0.12 else 0
    fatigue = 1 if random.random() < 0.18 else 0
    breathless = 1 if random.random() < 0.06 else 0

    return {
        "device_id": device_id,
        "heart_rate": hr,
        "spo2": spo2,
        "temperature": temp,
        "systolic_bp": sys,
        "diastolic_bp": dia,
        "cough": cough,
        "fatigue": fatigue,
        "breathless": breathless,
        "timestamp": None
    }


def run(device_id="device-001", interval=3):
    client = mqtt.Client()
    client.connect(BROKER, PORT, 60)
    client.loop_start()
    try:
        while True:
            reading = make_reading(device_id)
            topic = TOPIC_TEMPLATE.format(device_id=device_id)
            client.publish(topic, json.dumps(reading))
            print("published", reading)
            time.sleep(interval)
    except KeyboardInterrupt:
        print("stopping simulator")
    finally:
        client.loop_stop()
        client.disconnect()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--device-id", default="device-001")
    parser.add_argument("--interval", type=float, default=3.0)
    args = parser.parse_args()
    run(device_id=args.device_id, interval=args.interval)