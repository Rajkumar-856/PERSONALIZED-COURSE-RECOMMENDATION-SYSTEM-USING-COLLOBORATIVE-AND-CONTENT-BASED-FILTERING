"""
MQTT subscriber logic. When a message arrives on configured topic, it:
- decodes JSON payload (expected to match DeviceReading schema)
- stores reading to DB
- calls model.predict and stores prediction
- calls an optional callback to broadcast result (e.g., to a websocket manager)
"""
import json
import threading
import paho.mqtt.client as mqtt
from typing import Callable, Optional
from app.db import SessionLocal, save_reading, save_prediction
from app.ml_model import DiseaseModel

MQTT_BROKER = "localhost"
MQTT_PORT = 1883
TOPIC = "healthcare/device/+/data"  # wildcard: device id

model = DiseaseModel()


class MQTTListener:
    def __init__(self, broker=MQTT_BROKER, port=MQTT_PORT, topic=TOPIC):
        self.broker = broker
        self.port = port
        self.topic = topic
        self.client = mqtt.Client()
        self.callback: Optional[Callable[[dict], None]] = None

        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message

    def set_broadcast_callback(self, cb: Callable[[dict], None]):
        self.callback = cb

    def _on_connect(self, client, userdata, flags, rc):
        print("Connected to MQTT broker with rc=", rc)
        client.subscribe(self.topic)
        print(f"Subscribed to topic {self.topic}")

    def _on_message(self, client, userdata, msg):
        try:
            payload = json.loads(msg.payload.decode("utf-8"))
        except Exception as e:
            print("Failed to decode message:", e)
            return

        # store reading and run prediction
        session = SessionLocal()
        try:
            saved = save_reading(session, payload)
            result = model.predict(payload)
            pred_obj = save_prediction(session, payload.get("device_id", "unknown"), result["prediction"], result["probabilities"])
            # prepare broadcast payload
            out = {
                "device_id": payload.get("device_id"),
                "reading_id": saved.id,
                "prediction_id": pred_obj.id,
                "prediction": result["prediction"],
                "probabilities": result["probabilities"],
            }
            if self.callback:
                try:
                    self.callback(out)
                except Exception as e:
                    print("Callback error:", e)
        finally:
            session.close()

    def start(self):
        # connect and loop in background thread
        def run():
            self.client.connect(self.broker, self.port, keepalive=60)
            self.client.loop_forever()

        t = threading.Thread(target=run, daemon=True)
        t.start()