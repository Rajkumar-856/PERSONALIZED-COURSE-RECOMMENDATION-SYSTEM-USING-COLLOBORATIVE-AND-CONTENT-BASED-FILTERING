"""
FastAPI app that serves recommendations.

Endpoints:
- GET / -> static index.html
- GET /recommend/{user_id}?k=10&type=hybrid -> returns top-k course recommendations
- GET /course/{course_id} -> returns course metadata
- POST /feedback -> submit new rating (appends to data/interactions.csv) [simple demonstration only]
"""
import os
from fastapi import FastAPI, Request, HTTPException, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from typing import Optional
import joblib
import pandas as pd
import datetime
import csv

from app.models import ContentRecommender, CFRecommender, HybridRecommender

BASE_DIR = os.path.dirname(__file__)
MODEL_DIR = os.path.join(BASE_DIR, "..", "models")
DATA_DIR = os.path.join(BASE_DIR, "..", "data")

# Load artifacts
art = joblib.load(os.path.join(MODEL_DIR, "dataframes.joblib"))
courses_df = art["courses_df"]
users_df = art["users_df"]

content_meta = joblib.load(os.path.join(MODEL_DIR, "content_meta.joblib"))
content_vectors = joblib.load(os.path.join(MODEL_DIR, "content_vectors.joblib"))
cf_meta = joblib.load(os.path.join(MODEL_DIR, "cf_meta.joblib"))
cf_factors = joblib.load(os.path.join(MODEL_DIR, "cf_factors.joblib"))
hybrid_meta = joblib.load(os.path.join(MODEL_DIR, "hybrid_meta.joblib"))

# instantiate recommenders and load artifacts
content_rec = ContentRecommender()
content_rec.vectorizer = content_meta["vectorizer"]
content_rec.item_index = content_meta["item_index"]
content_rec.item_vectors = content_vectors["item_vectors"]

cf_rec = CFRecommender(n_components=cf_meta["n_components"])
cf_rec.user_index = cf_meta["user_index"]
cf_rec.item_index = cf_meta["item_index"]
cf_rec.user_factors = cf_factors["user_factors"]
cf_rec.item_factors = cf_factors["item_factors"]

hybrid = HybridRecommender(content_rec, cf_rec, alpha=hybrid_meta["alpha"])

app = FastAPI(title="Course Recommender API")
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "..", "static"))
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "..", "static")), name="static")


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/recommend/{user_id}")
def recommend(user_id: int, k: int = 10, type: Optional[str] = "hybrid"):
    # load interactions fresh to reflect any updates (simple approach)
    interactions = pd.read_csv(os.path.join(DATA_DIR, "interactions.csv"))
    if user_id not in users_df["user_id"].astype(int).values:
        raise HTTPException(status_code=404, detail="User not found")
    if type == "content":
        recs = content_rec.recommend_for_user(interactions[interactions["user_id"] == user_id], courses_df, top_k=k)
    elif type == "cf":
        recs = cf_rec.recommend_for_user(user_id, interactions, courses_df, top_k=k)
    else:
        recs = hybrid.recommend_for_user(user_id, interactions, users_df, courses_df, top_k=k)
    # enrich with course metadata
    enriched = []
    for r in recs:
        cid = int(r["course_id"])
        row = courses_df[courses_df["course_id"] == cid].iloc[0].to_dict()
        row["score"] = r["score"]
        enriched.append(row)
    return JSONResponse({"user_id": user_id, "method": type, "recommendations": enriched})


@app.get("/course/{course_id}")
def get_course(course_id: int):
    row = courses_df[courses_df["course_id"] == course_id]
    if row.empty:
        raise HTTPException(status_code=404, detail="Course not found")
    return JSONResponse(row.iloc[0].to_dict())


@app.post("/feedback")
def feedback(user_id: int = Form(...), course_id: int = Form(...), rating: float = Form(...)):
    # Append to interactions.csv (very simple, no concurrency control)
    path = os.path.join(DATA_DIR, "interactions.csv")
    timestamp = datetime.datetime.utcnow().isoformat()
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([int(user_id), int(course_id), float(rating), timestamp])
    return JSONResponse({"status": "ok", "user_id": user_id, "course_id": course_id, "rating": rating})