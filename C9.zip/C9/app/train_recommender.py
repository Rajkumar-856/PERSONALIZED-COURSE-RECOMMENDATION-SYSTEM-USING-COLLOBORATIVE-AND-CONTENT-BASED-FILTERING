#!/usr/bin/env python3
"""
Train the content, CF, and hybrid recommenders on the synthetic dataset.
Saves artifacts into models/ directory.

Also performs a simple holdout evaluation:
 - For each user, hold out one interaction as test (if possible), train on the rest.
 - Compute Hit Rate@K for K in [5,10,20] and RMSE across predicted ratings for CF.

Run:
    python app/train_recommender.py
"""
import os
import pandas as pd
import numpy as np
from pprint import pprint
import joblib

from app.models import ContentRecommender, CFRecommender, HybridRecommender, MODEL_DIR

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
COURSES_CSV = os.path.join(DATA_DIR, "courses.csv")
USERS_CSV = os.path.join(DATA_DIR, "users.csv")
INTERACTIONS_CSV = os.path.join(DATA_DIR, "interactions.csv")


def load_data():
    courses = pd.read_csv(COURSES_CSV)
    users = pd.read_csv(USERS_CSV)
    interactions = pd.read_csv(INTERACTIONS_CSV)
    # ensure types
    courses["course_id"] = courses["course_id"].astype(int)
    users["user_id"] = users["user_id"].astype(int)
    interactions["user_id"] = interactions["user_id"].astype(int)
    interactions["course_id"] = interactions["course_id"].astype(int)
    interactions["rating"] = interactions["rating"].astype(float)
    return courses, users, interactions


def holdout_split(interactions):
    # per-user leave-one-out holdout
    interactions = interactions.copy()
    interactions = interactions.sort_values("timestamp")
    test_rows = []
    train_rows = []
    for uid, grp in interactions.groupby("user_id"):
        if len(grp) <= 1:
            # keep all in train
            train_rows.extend(grp.index.tolist())
            continue
        # take last as test
        test_idx = grp.index[-1]
        test_rows.append(test_idx)
        train_rows.extend(grp.index[:-1].tolist())
    train = interactions.loc[train_rows].reset_index(drop=True)
    test = interactions.loc[test_rows].reset_index(drop=True)
    return train, test


def hit_rate_at_k(recommender, train_interactions, test_interactions, users, courses, k=10):
    hits = 0
    total = 0
    for uid in test_interactions["user_id"].unique():
        test_row = test_interactions[test_interactions["user_id"] == uid]
        if test_row.empty:
            continue
        true_cid = int(test_row.iloc[0]["course_id"])
        recs = recommender.recommend_for_user(uid, train_interactions, users, courses, top_k=k)
        rec_cids = [r["course_id"] for r in recs]
        if true_cid in rec_cids:
            hits += 1
        total += 1
    return hits / total if total > 0 else 0.0


def evaluate_models(content, cf, hybrid, train, test, users, courses):
    ks = [5, 10, 20]
    results = {}
    for k in ks:
        c_hr = hit_rate_at_k(content, train, test, users, courses, k=k)
        cf_hr = hit_rate_at_k(cf, train, test, users, courses, k=k)
        h_hr = hit_rate_at_k(hybrid, train, test, users, courses, k=k)
        results[f"HR@{k}"] = {"content": c_hr, "cf": cf_hr, "hybrid": h_hr}
    return results


if __name__ == "__main__":
    courses, users, interactions = load_data()
    print("Loaded data:", courses.shape, users.shape, interactions.shape)

    train, test = holdout_split(interactions)
    print("Train/test split:", train.shape, test.shape)

    # Train content model
    content = ContentRecommender()
    content.fit(courses)
    content.build_item_vectors_from_df(courses)
    joblib.dump({"item_vectors": content.item_vectors}, os.path.join(MODEL_DIR, "content_vectors.joblib"))
    print("Trained content recommender.")

    # Train CF
    cf = CFRecommender(n_components=50)
    cf.fit(train, users, courses)
    print("Trained CF recommender.")

    # Hybrid
    hybrid = HybridRecommender(content, cf, alpha=0.5)

    # Evaluate
    print("Evaluating models...")
    results = evaluate_models(content, cf, hybrid, train, test, users, courses)
    pprint(results)

    # Save meta hybrid config
    joblib.dump({"alpha": hybrid.alpha}, os.path.join(MODEL_DIR, "hybrid_meta.joblib"))

    # Save helpful artifacts for API (courses and users)
    joblib.dump({"courses_df": courses, "users_df": users}, os.path.join(MODEL_DIR, "dataframes.joblib"))
    print(f"Saved models and artifacts to {MODEL_DIR}")

    print("Done.")