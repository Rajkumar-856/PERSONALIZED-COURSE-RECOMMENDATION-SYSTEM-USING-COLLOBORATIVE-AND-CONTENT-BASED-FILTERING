"""
FastAPI app exposing endpoints to analyze text and to inspect the blockchain.

Endpoints:
- GET /            -> static demo UI
- POST /api/analyze -> accept text (form/json), run model, store record, append blockchain anchor
- GET /api/chain   -> return chain blocks (JSON)
- GET /api/records -> return stored content records

Start with:
    uvicorn app.main:app --reload
"""
import hashlib
import json
from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from typing import Optional

from app.ml_model import FakeDetector
from app.blockchain import SimpleChain, sha256_hex
from app.db import init_db, SessionLocal, save_content, save_chain

import os

app = FastAPI(title="Fake Media Detector + Blockchain Ledger")

BASE_DIR = os.path.dirname(__file__)
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "..", "static"))
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "..", "static")), name="static")

# Initialize DB and in-memory chain
detector = FakeDetector()
chain = SimpleChain()


@app.on_event("startup")
def startup():
    init_db()


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/api/analyze")
async def analyze(request: Request):
    """
    Accepts application/json or form data with fields:
    - text (required)
    - source (optional)
    """
    # Accept json or form
    data = {}
    try:
        data = await request.json()
    except Exception:
        form = await request.form()
        data = dict(form)

    text = data.get("text")
    source = data.get("source", None)
    if not text:
        raise HTTPException(status_code=400, detail="Missing 'text' field.")

    # Run model
    result = detector.predict(text)
    prediction = result["prediction"]
    probabilities = result["probabilities"]

    # Compute content hash (canonicalization: simple trim + lower)
    canonical = " ".join(text.strip().split()).lower()
    content_hash = sha256_hex(canonical)

    # Save to DB
    session = SessionLocal()
    try:
        content_rec = save_content(session, text, source, prediction, probabilities, content_hash)
        # Append to chain (in-memory) and save chain record
        block = chain.add_block(content_hash)
        chain_rec = save_chain(session, block)
    finally:
        session.close()

    out = {
        "content_id": content_rec.id,
        "prediction": prediction,
        "probabilities": probabilities,
        "content_hash": content_hash,
        "block": block.to_dict()
    }
    return JSONResponse(out)


@app.get("/api/chain")
def get_chain():
    return JSONResponse({"chain": chain.to_list(), "valid": chain.is_valid()})


@app.get("/api/records")
def get_records():
    session = SessionLocal()
    try:
        rows = session.query.__self__.execute  # cheap guard to keep session alive for ORM; but we'll do SQL for simplicity
        # Query all content records
        query = session.query
        recs = []
        for c in query(SessionLocal().get_bind().engine.table_names()):  # Not used; avoid complex introspection
            pass
        # Simpler approach: use raw SQL
        res = session.execute("SELECT id, text, source, prediction, probabilities, content_hash, timestamp FROM contents ORDER BY id DESC LIMIT 200")
        for row in res.fetchall():
            recs.append({
                "id": row[0],
                "text": row[1],
                "source": row[2],
                "prediction": row[3],
                "probabilities": json.loads(row[4]) if isinstance(row[4], str) else row[4],
                "content_hash": row[5],
                "timestamp": row[6].isoformat() if row[6] is not None else None
            })
        return JSONResponse({"records": recs})
    finally:
        session.close()