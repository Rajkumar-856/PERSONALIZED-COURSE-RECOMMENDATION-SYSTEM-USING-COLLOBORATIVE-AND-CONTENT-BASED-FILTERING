"""
Model loading and prediction helper.
"""
import os
import joblib
from pathlib import Path
from typing import Dict, Any

MODEL_PATH = Path(__file__).parent / "model.pkl"


class FakeDetector:
    def __init__(self, path: str = None):
        p = path or str(MODEL_PATH)
        payload = joblib.load(p)
        self.pipeline = payload["pipeline"]

    def predict(self, text: str) -> Dict[str, Any]:
        proba = self.pipeline.predict_proba([text])[0]
        classes = list(self.pipeline.classes_)
        prob_map = {classes[i]: float(proba[i]) for i in range(len(classes))}
        pred = self.pipeline.predict([text])[0]
        return {"prediction": pred, "probabilities": prob_map}