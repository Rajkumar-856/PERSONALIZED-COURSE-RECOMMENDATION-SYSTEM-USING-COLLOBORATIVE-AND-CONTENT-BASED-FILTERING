"""
Train a simple TF-IDF + LogisticRegression model on synthetic fake/real text data.
Saves a sklearn Pipeline to app/model.pkl.
"""
import os
import random
import joblib
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

OUT_PATH = Path(__file__).parent / "model.pkl"


REAL_TEMPLATES = [
    "The study published by {source} shows significant improvements in the treatment of {topic}.",
    "According to multiple verified reports, {person} confirmed that the event occurred as described.",
    "Experts say that {topic} has been improving steadily over the past year.",
    "{org} released an official statement clarifying the situation and providing data.",
    "The verified dataset contains the measurements and the methodology is openly available."
]

FAKE_TEMPLATES = [
    "Shocking! You won't believe what {person} said about {topic} — click to learn the hidden truth!",
    "Government hides the real facts about {topic}; insiders reveal a secret plan.",
    "Miracle discovered: {topic} cure exposed by unknown researchers.",
    "This viral post claims {person} supports the conspiracy about {topic}.",
    "Unverified footage shows dramatic events that mainstream sources refuse to show."
]

SOURCES = ["Nature", "The Journal", "TrustedNews", "HealthWatch", "ScienceDaily"]
TOPICS = ["economy", "vaccines", "climate", "AI research", "public health"]
PEOPLE = ["Dr. Smith", "an anonymous insider", "a local source", "a whistleblower", "the mayor"]
ORGS = ["Ministry of Health", "University Lab", "Global Health Org", "City Council"]


def make_sentence(template_list, n, label):
    rows = []
    rng = random.Random(42 + (1 if label == "fake" else 2))
    for _ in range(n):
        temp = rng.choice(template_list)
        text = temp.format(
            source=rng.choice(SOURCES),
            topic=rng.choice(TOPICS),
            person=rng.choice(PEOPLE),
            org=rng.choice(ORGS),
        )
        # Add small variations/noise
        if rng.random() < 0.2:
            text += " " + rng.choice(["Read more.", "See details.", "Full report inside."])
        rows.append(text)
    return rows


def generate_dataset(n_real=2000, n_fake=2000):
    real = make_sentence(REAL_TEMPLATES, n_real, "real")
    fake = make_sentence(FAKE_TEMPLATES, n_fake, "fake")
    df = pd.DataFrame({
        "text": real + fake,
        "label": ["real"] * n_real + ["fake"] * n_fake
    })
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    return df


def train_and_save(out_path=OUT_PATH):
    df = generate_dataset()
    X = df["text"]
    y = df["label"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1,2), max_features=8000)),
        ("clf", LogisticRegression(max_iter=1000))
    ])
    pipeline.fit(X_train, y_train)

    preds = pipeline.predict(X_test)
    print("Classification report on synthetic test set:")
    print(classification_report(y_test, preds))

    joblib.dump({"pipeline": pipeline, "trained_at": datetime.utcnow()}, out_path)
    print(f"Saved model to {out_path}")


if __name__ == "__main__":
    train_and_save()