"""
SQLite persistence using SQLAlchemy for analyzed content and chain anchors.
"""
import os
from datetime import datetime
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

DB_PATH = os.path.join(os.path.dirname(__file__), "app.db")
ENGINE = create_engine(f"sqlite:///{DB_PATH}", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=ENGINE)
Base = declarative_base()


class ContentRecord(Base):
    __tablename__ = "contents"
    id = Column(Integer, primary_key=True, index=True)
    text = Column(String, nullable=False)
    source = Column(String, nullable=True)
    prediction = Column(String, nullable=False)
    probabilities = Column(JSON)
    content_hash = Column(String, nullable=False, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow)


class ChainRecord(Base):
    __tablename__ = "chain"
    id = Column(Integer, primary_key=True, index=True)
    block_index = Column(Integer, nullable=False)
    block_hash = Column(String, nullable=False)
    previous_hash = Column(String, nullable=True)
    data_hash = Column(String, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)


def init_db():
    Base.metadata.create_all(bind=ENGINE)


def save_content(session, text: str, source: str, prediction: str, probabilities: dict, content_hash: str):
    r = ContentRecord(
        text=text,
        source=source,
        prediction=prediction,
        probabilities=probabilities,
        content_hash=content_hash
    )
    session.add(r)
    session.commit()
    session.refresh(r)
    return r


def save_chain(session, block):
    cr = ChainRecord(
        block_index=block.index,
        block_hash=block.hash,
        previous_hash=block.previous_hash,
        data_hash=block.data_hash
    )
    session.add(cr)
    session.commit()
    session.refresh(cr)
    return cr