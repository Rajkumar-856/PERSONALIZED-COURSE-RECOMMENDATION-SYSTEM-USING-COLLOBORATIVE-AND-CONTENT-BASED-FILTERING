from pydantic import BaseModel, Field
from typing import Optional, Dict, Any


class DeviceReading(BaseModel):
    device_id: str
    heart_rate: float = Field(..., example=72.5)
    spo2: float = Field(..., example=97.0)
    temperature: float = Field(..., example=36.8)
    systolic_bp: float = Field(..., example=120)
    diastolic_bp: float = Field(..., example=75)
    cough: int = Field(0, ge=0, le=1)
    fatigue: int = Field(0, ge=0, le=1)
    breathless: int = Field(0, ge=0, le=1)
    timestamp: Optional[str] = None


class PredictionResult(BaseModel):
    prediction: str
    probabilities: Dict[str, float]