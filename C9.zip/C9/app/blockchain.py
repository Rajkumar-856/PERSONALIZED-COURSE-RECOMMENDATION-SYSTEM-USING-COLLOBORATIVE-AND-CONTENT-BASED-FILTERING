"""
A minimal, educational blockchain implementation that records content hashes.
Each block contains:
- index, timestamp, data_hash (hash of the content), previous_hash, nonce, block_hash.

Block hash is SHA-256 over the block fields (index, timestamp, data_hash, previous_hash, nonce).
This is NOT a production blockchain; it's a simple tamper-evident ledger for demo purposes.
"""
import hashlib
import json
from time import time
from typing import List, Dict, Any


def sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


class Block:
    def __init__(self, index: int, timestamp: float, data_hash: str, previous_hash: str, nonce: int = 0):
        self.index = index
        self.timestamp = timestamp
        self.data_hash = data_hash
        self.previous_hash = previous_hash
        self.nonce = nonce
        self.hash = self.compute_hash()

    def compute_hash(self) -> str:
        block_string = json.dumps({
            "index": self.index,
            "timestamp": self.timestamp,
            "data_hash": self.data_hash,
            "previous_hash": self.previous_hash,
            "nonce": self.nonce
        }, sort_keys=True)
        return sha256_hex(block_string)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "index": self.index,
            "timestamp": self.timestamp,
            "data_hash": self.data_hash,
            "previous_hash": self.previous_hash,
            "nonce": self.nonce,
            "hash": self.hash
        }


class SimpleChain:
    def __init__(self):
        self.chain: List[Block] = []
        # create genesis
        genesis = Block(index=0, timestamp=time(), data_hash="GENESIS", previous_hash="0")
        self.chain.append(genesis)

    def last_block(self) -> Block:
        return self.chain[-1]

    def add_block(self, data_hash: str) -> Block:
        prev = self.last_block()
        index = prev.index + 1
        block = Block(index=index, timestamp=time(), data_hash=data_hash, previous_hash=prev.hash)
        self.chain.append(block)
        return block

    def is_valid(self) -> bool:
        for i in range(1, len(self.chain)):
            curr = self.chain[i]
            prev = self.chain[i - 1]
            if curr.previous_hash != prev.hash:
                return False
            if curr.compute_hash() != curr.hash:
                return False
        return True

    def to_list(self):
        return [b.to_dict() for b in self.chain]