"""
Recommender classes:
- ContentRecommender: TF-IDF on descriptions -> item vectors, builds user profile by weighted average of liked items
- CFRecommender: simple matrix factorization with TruncatedSVD on user-item rating matrix
- HybridRecommender: weighted ensemble of content + cf scores
"""
from typing import List, Dict, Any
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import TruncatedSVD
from sklearn.preprocessing import StandardScaler

import joblib
import os

MODEL_DIR = os.path.join(os.path.dirname(__file__), "..", "models")
os.makedirs(MODEL_DIR, exist_ok=True)


class ContentRecommender:
    def __init__(self):
        self.vectorizer: TfidfVectorizer = TfidfVectorizer(ngram_range=(1,2), max_features=5000)
        self.item_vectors = None
        self.item_index = None  # map course_id -> row idx

    def fit(self, courses: pd.DataFrame):
        texts = courses["description"].fillna(courses["title"]).astype(str).values
        self.item_vectors = self.vectorizer.fit_transform(texts)
        # index mapping
        self.item_index = {int(cid): idx for idx, cid in enumerate(courses["course_id"].values)}
        # save metadata for serving
        joblib.dump({"vectorizer": self.vectorizer, "item_index": self.item_index}, os.path.join(MODEL_DIR, "content_meta.joblib"))

    def load(self):
        meta = joblib.load(os.path.join(MODEL_DIR, "content_meta.joblib"))
        self.vectorizer = meta["vectorizer"]
        self.item_index = meta["item_index"]
        # item_vectors must be loaded externally by trainer (or saved separately) — caller should set it.

    def build_item_vectors_from_df(self, courses: pd.DataFrame):
        texts = courses["description"].fillna(courses["title"]).astype(str).values
        self.item_vectors = self.vectorizer.transform(texts)

    def user_profile(self, interactions: pd.DataFrame, positive_threshold=4.0):
        # interactions: rows for that user with course_id and rating
        # Build profile as avg of item vectors weighted by (rating - 3)
        rows = []
        weights = []
        for _, r in interactions.iterrows():
            cid = int(r["course_id"])
            rating = float(r["rating"])
            if cid not in self.item_index:
                continue
            idx = self.item_index[cid]
            vec = self.item_vectors[idx].toarray().ravel()
            weight = max(0.0, rating - 3.0)  # only positive signal adds
            if weight > 0:
                rows.append(vec * weight)
                weights.append(weight)
        if not rows:
            # cold start: return zero vector
            return np.zeros(self.item_vectors.shape[1])
        profile = np.sum(rows, axis=0) / (np.sum(weights) + 1e-9)
        return profile

    def recommend_for_user(self, user_interactions: pd.DataFrame, courses: pd.DataFrame, top_k=10):
        profile = self.user_profile(user_interactions)
        sims = cosine_similarity(profile.reshape(1, -1), self.item_vectors).ravel()
        # mask already seen items
        seen = set(user_interactions["course_id"].astype(int).tolist())
        recs = []
        for cid, idx in self.item_index.items():
            if cid in seen:
                sims[idx] = -1.0
        top_idx = np.argsort(-sims)[:top_k]
        for idx in top_idx:
            # find course id by reverse lookup
            for cid, i in self.item_index.items():
                if i == idx:
                    recs.append({"course_id": cid, "score": float(sims[idx])})
                    break
        return recs


class CFRecommender:
    def __init__(self, n_components=50):
        self.n_components = n_components
        self.user_index = {}  # user_id -> row
        self.item_index = {}  # course_id -> col
        self.user_factors = None
        self.item_factors = None
        self.scaler = StandardScaler(with_mean=False)

    def fit(self, interactions: pd.DataFrame, users: pd.DataFrame, courses: pd.DataFrame):
        # Build user-item matrix (users x items)
        unique_users = users["user_id"].astype(int).unique()
        unique_items = courses["course_id"].astype(int).unique()
        self.user_index = {int(uid): i for i, uid in enumerate(unique_users)}
        self.item_index = {int(cid): j for j, cid in enumerate(unique_items)}
        mat = np.zeros((len(unique_users), len(unique_items)), dtype=float)
        for _, r in interactions.iterrows():
            u = int(r["user_id"])
            c = int(r["course_id"])
            if u in self.user_index and c in self.item_index:
                mat[self.user_index[u], self.item_index[c]] = float(r["rating"])
        # Optionally scale
        mat_scaled = self.scaler.fit_transform(mat)
        # SVD
        svd = TruncatedSVD(n_components=min(self.n_components, min(mat_scaled.shape)-1), random_state=42)
        user_factors = svd.fit_transform(mat_scaled)
        item_factors = svd.components_.T
        self.user_factors = user_factors
        self.item_factors = item_factors
        # persist meta
        joblib.dump({"user_index": self.user_index, "item_index": self.item_index, "n_components": self.n_components}, os.path.join(MODEL_DIR, "cf_meta.joblib"))
        joblib.dump({"user_factors": self.user_factors, "item_factors": self.item_factors}, os.path.join(MODEL_DIR, "cf_factors.joblib"))

    def load(self):
        meta = joblib.load(os.path.join(MODEL_DIR, "cf_meta.joblib"))
        factors = joblib.load(os.path.join(MODEL_DIR, "cf_factors.joblib"))
        self.user_index = meta["user_index"]
        self.item_index = meta["item_index"]
        self.n_components = meta["n_components"]
        self.user_factors = factors["user_factors"]
        self.item_factors = factors["item_factors"]

    def recommend_for_user(self, user_id: int, interactions: pd.DataFrame, courses: pd.DataFrame, top_k=10):
        if user_id not in self.user_index:
            # cold start: fallback to popularity
            item_pop = interactions.groupby("course_id")["rating"].mean().sort_values(ascending=False)
            recs = [{"course_id": int(cid), "score": float(score)} for cid, score in item_pop.head(top_k).items()]
            return recs
        uidx = self.user_index[user_id]
        user_vector = self.user_factors[uidx]
        scores = user_vector.dot(self.item_factors.T)
        # mask seen
        seen = set(interactions[interactions["user_id"] == user_id]["course_id"].astype(int).tolist())
        recs = []
        for cid, j in self.item_index.items():
            if cid in seen:
                scores[j] = -1e9
        top_idx = np.argsort(-scores)[:top_k]
        for j in top_idx:
            # find course id by reverse lookup
            for cid, idx in self.item_index.items():
                if idx == j:
                    recs.append({"course_id": cid, "score": float(scores[j])})
                    break
        return recs


class HybridRecommender:
    def __init__(self, content_rec: ContentRecommender, cf_rec: CFRecommender, alpha=0.5):
        self.content = content_rec
        self.cf = cf_rec
        self.alpha = alpha  # weight for content; cf weight = 1 - alpha

    def recommend_for_user(self, user_id: int, interactions: pd.DataFrame, users: pd.DataFrame, courses: pd.DataFrame, top_k=10):
        # get content scores
        user_inter = interactions[interactions["user_id"] == user_id]
        content_recs = self.content.recommend_for_user(user_inter, courses, top_k=200)
        content_map = {r["course_id"]: r["score"] for r in content_recs}
        # get cf scores
        cf_recs = self.cf.recommend_for_user(user_id, interactions, courses, top_k=200)
        cf_map = {r["course_id"]: r["score"] for r in cf_recs}
        # union keys
        all_cids = set(list(content_map.keys()) + list(cf_map.keys()))
        combined = []
        # normalize scores
        c_vals = np.array(list(content_map.values())) if content_map else np.array([0.0])
        cf_vals = np.array(list(cf_map.values())) if cf_map else np.array([0.0])
        c_min, c_max = c_vals.min() if c_vals.size else 0.0, c_vals.max() if c_vals.size else 1.0
        cf_min, cf_max = cf_vals.min() if cf_vals.size else 0.0, cf_vals.max() if cf_vals.size else 1.0

        def norm(v, mn, mx):
            if mx - mn == 0:
                return 0.0
            return (v - mn) / (mx - mn)

        for cid in all_cids:
            cscore = norm(content_map.get(cid, 0.0), c_min, c_max)
            cfscore = norm(cf_map.get(cid, 0.0), cf_min, cf_max)
            score = self.alpha * cscore + (1.0 - self.alpha) * cfscore
            combined.append({"course_id": cid, "score": float(score)})
        combined_sorted = sorted(combined, key=lambda x: -x["score"])[:top_k]
        return combined_sorted