#!/usr/bin/env python3
"""
Generate synthetic dataset:
- courses.csv: id, title, category, level, description
- users.csv: id, name, interests (comma-separated)
- interactions.csv: user_id, course_id, rating (1-5), timestamp

Run:
    python data/generate_synthetic.py
"""
import os
import csv
import random
import json
from datetime import datetime, timedelta

OUT_DIR = os.path.join(os.path.dirname(__file__))

COURSE_COUNT = 200
USER_COUNT = 600
INTERACTIONS = 6000  # number of generated ratings

CATEGORIES = [
    "Data Science", "Web Development", "Cloud", "Mobile Development",
    "Business", "Design", "Cybersecurity", "AI & ML"
]
LEVELS = ["Beginner", "Intermediate", "Advanced"]

COURSE_TEMPLATES = [
    "Learn {topic} from scratch with practical projects and hands-on labs.",
    "A complete {topic} course covering fundamentals, best practices, and real-world cases.",
    "Master {topic} with guided examples, quizzes, and capstone projects.",
    "Deep dive into {topic}, algorithms, and implementation details with Python.",
    "Practical {topic} for building production-ready applications and services."
]

USER_INTERESTS = {
    "Data Science": ["machine learning", "data analysis", "statistics", "pandas", "numpy"],
    "Web Development": ["javascript", "react", "html", "css", "frontend"],
    "Cloud": ["aws", "azure", "gcp", "infrastructure", "devops"],
    "Mobile Development": ["android", "ios", "flutter", "react native"],
    "Business": ["marketing", "finance", "product", "strategy"],
    "Design": ["ux", "ui", "figma", "prototyping"],
    "Cybersecurity": ["security", "pen testing", "cryptography"],
    "AI & ML": ["deep learning", "neural networks", "tensorflow", "pytorch"]
}


def make_courses(n=COURSE_COUNT):
    courses = []
    rng = random.Random(42)
    for i in range(1, n + 1):
        cat = rng.choice(CATEGORIES)
        level = rng.choice(LEVELS)
        topic = rng.choice(USER_INTERESTS[cat]) if cat in USER_INTERESTS else "general"
        title = f"{topic.title()} for {cat}"
        desc_template = rng.choice(COURSE_TEMPLATES)
        description = desc_template.format(topic=topic)
        courses.append({
            "course_id": i,
            "title": title,
            "category": cat,
            "level": level,
            "description": description
        })
    return courses


def make_users(n=USER_COUNT):
    users = []
    rng = random.Random(123)
    for i in range(1, n + 1):
        # each user has 1-3 interests
        interested_cats = rng.sample(CATEGORIES, rng.randint(1, 3))
        interests = []
        for c in interested_cats:
            interests.append(rng.choice(USER_INTERESTS[c]))
        users.append({
            "user_id": i,
            "name": f"user_{i}",
            "interests": ",".join(interests)
        })
    return users


def make_interactions(users, courses, m=INTERACTIONS):
    rng = random.Random(999)
    interactions = []
    # create a bias: users prefer courses in categories close to their interests
    course_by_id = {c["course_id"]: c for c in courses}
    for _ in range(m):
        u = rng.choice(users)
        # choose course: mostly from user's interest categories, sometimes random
        if rng.random() < 0.75:
            # try to pick a course matching one of the user's interest keywords
            interest = rng.choice(u["interests"].split(","))
            # find courses whose title or description contain keyword
            candidates = [c for c in courses if interest.lower() in c["title"].lower() or interest.lower() in c["description"].lower()]
            if not candidates:
                candidates = courses
            c = rng.choice(candidates)
        else:
            c = rng.choice(courses)
        # rating depends on match quality
        base = 3.0
        if any(k in c["title"].lower() or k in c["description"].lower() for k in u["interests"].split(",")):
            base += rng.uniform(0.5, 1.5)
        # add some noise
        rating = min(5, max(1, round(base + rng.gauss(0, 0.7))))
        timestamp = datetime.utcnow() - timedelta(days=rng.randint(0, 365))
        interactions.append({
            "user_id": u["user_id"],
            "course_id": c["course_id"],
            "rating": rating,
            "timestamp": timestamp.isoformat()
        })
    # ensure every user has at least 5 interactions
    for u in users:
        u_id = u["user_id"]
        user_inter = [it for it in interactions if it["user_id"] == u_id]
        while len(user_inter) < 5:
            c = random.choice(courses)
            rating = random.randint(3, 5)
            timestamp = datetime.utcnow() - timedelta(days=random.randint(0, 365))
            interactions.append({
                "user_id": u_id,
                "course_id": c["course_id"],
                "rating": rating,
                "timestamp": timestamp.isoformat()
            })
            user_inter = [it for it in interactions if it["user_id"] == u_id]
    return interactions


def write_csv(path, rows, fieldnames):
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow(r)


if __name__ == "__main__":
    os.makedirs(OUT_DIR, exist_ok=True)
    courses = make_courses()
    users = make_users()
    interactions = make_interactions(users, courses)

    write_csv(os.path.join(OUT_DIR, "courses.csv"), courses, ["course_id", "title", "category", "level", "description"])
    write_csv(os.path.join(OUT_DIR, "users.csv"), users, ["user_id", "name", "interests"])
    write_csv(os.path.join(OUT_DIR, "interactions.csv"), interactions, ["user_id", "course_id", "rating", "timestamp"])

    print("Generated synthetic dataset:")
    print(f" - courses: {len(courses)} -> data/courses.csv")
    print(f" - users: {len(users)} -> data/users.csv")
    print(f" - interactions: {len(interactions)} -> data/interactions.csv")