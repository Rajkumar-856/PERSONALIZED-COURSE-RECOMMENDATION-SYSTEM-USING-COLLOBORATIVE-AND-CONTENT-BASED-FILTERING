#!/usr/bin/env python3
"""
Cross-validation and ensembled regression for residential property valuation.

Uses the sklearn California Housing dataset as a realistic demo dataset.
Steps:
 - load dataset
 - simple feature engineering
 - build preprocessing pipeline
 - define base models (Linear, RandomForest, GradientBoosting, optional XGBoost)
 - evaluate each model with K-Fold cross-validation (RMSE, MAE, R2)
 - demonstrate a StackingRegressor ensemble
 - optional GridSearch for RandomForest
 - save the best model to disk

Run:
    python train_evaluate.py
"""
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import joblib
from time import time
from pprint import pprint

from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import KFold, cross_val_score, GridSearchCV, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, FunctionTransformer, PolynomialFeatures
from sklearn.linear_model import LinearRegression, RidgeCV
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, StackingRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.base import clone

# Optional: XGBoost
try:
    from xgboost import XGBRegressor
    HAS_XGBOOST = True
except Exception:
    HAS_XGBOOST = False

RANDOM_STATE = 42
CV_FOLDS = 5
MODEL_OUT = "best_model.joblib"


def load_data():
    # Use the California housing dataset as demo
    ds = fetch_california_housing(as_frame=True)
    X = ds.frame.drop(columns=["MedHouseVal"])  # features
    y = ds.frame["MedHouseVal"]                 # target (median house value)
    return X, y


def feature_engineering(df: pd.DataFrame) -> pd.DataFrame:
    # Add a few derived features that are often useful for housing data
    df = df.copy()
    # rooms per household and bedrooms per room are frequently used
    if {"AveRooms", "AveBedrms", "AveOccup", "Population"}.issubset(df.columns):
        df["rooms_per_household"] = df["AveRooms"] / (df["AveOccup"] + 1e-6)
        df["bedrooms_per_room"] = df["AveBedrms"] / (df["AveRooms"] + 1e-6)
        df["population_per_household"] = df["Population"] / (df["AveOccup"] + 1e-6)
    # lat/long interactions (very simplistic)
    if {"Latitude", "Longitude"}.issubset(df.columns):
        df["lat_long_interaction"] = df["Latitude"] * df["Longitude"]
    return df


def build_preprocessor(poly: bool = False):
    # For this demo all fields are numeric. We'll standardize them.
    steps = []
    steps.append(("scaler", StandardScaler()))
    if poly:
        # Optionally add low-degree polynomial features (careful with collinearity)
        steps.append(("poly", PolynomialFeatures(degree=2, include_bias=False)))
    return Pipeline(steps)


def cv_metrics(model, X, y, cv=CV_FOLDS):
    """Compute cross-validated RMSE, MAE, R2 using KFold"""
    kf = KFold(n_splits=cv, shuffle=True, random_state=RANDOM_STATE)
    rmses = []
    maes = []
    r2s = []
    fold = 0
    for train_idx, test_idx in kf.split(X):
        fold += 1
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]
        m = clone(model)
        m.fit(X_train, y_train)
        pred = m.predict(X_test)
        rmses.append(mean_squared_error(y_test, pred, squared=False))  # RMSE
        maes.append(mean_absolute_error(y_test, pred))
        r2s.append(r2_score(y_test, pred))
    return {
        "rmse_mean": float(np.mean(rmses)),
        "rmse_std": float(np.std(rmses)),
        "mae_mean": float(np.mean(maes)),
        "r2_mean": float(np.mean(r2s))
    }


def main():
    print("Loading data...")
    X_df, y_series = load_data()
    print("Original shape:", X_df.shape)

    print("Applying feature engineering...")
    X_df = feature_engineering(X_df)
    print("Post-feature shape:", X_df.shape)

    # Convert to numpy arrays for pipelines that expect arrays
    X = X_df.values
    y = y_series.values

    # Preprocessor (experiment: toggle poly True/False)
    preprocessor = build_preprocessor(poly=False)

    # Define base models (wrapped in a pipeline with preprocessing)
    models = {}

    models["Linear"] = Pipeline([("prep", preprocessor), ("lr", LinearRegression())])
    models["RidgeCV"] = Pipeline([("prep", preprocessor), ("ridge", RidgeCV(alphas=[0.1, 1.0, 10.0]))])
    models["RandomForest"] = Pipeline([("prep", preprocessor), ("rf", RandomForestRegressor(n_estimators=200, random_state=RANDOM_STATE, n_jobs=-1))])
    models["GradientBoosting"] = Pipeline([("prep", preprocessor), ("gbr", GradientBoostingRegressor(n_estimators=200, random_state=RANDOM_STATE))])

    if HAS_XGBOOST:
        models["XGBoost"] = Pipeline([("prep", preprocessor), ("xgb", XGBRegressor(n_estimators=200, random_state=RANDOM_STATE, verbosity=0))])
    else:
        print("XGBoost not installed; skipping XGBoost model.")

    # Evaluate each model with cross-validation
    print("\nCross-validating base models ({}-fold)...".format(CV_FOLDS))
    results = {}
    for name, mdl in models.items():
        t0 = time()
        res = cv_metrics(mdl, X, y, cv=CV_FOLDS)
        t1 = time()
        results[name] = res
        print(f"Model: {name:15} RMSE: {res['rmse_mean']:.4f} +/- {res['rmse_std']:.4f} | MAE: {res['mae_mean']:.4f} | R2: {res['r2_mean']:.4f} | time: {t1-t0:.1f}s")

    # Stacking ensemble (meta-learner)
    print("\nBuilding stacking ensemble...")
    # StackingRegressor will accept estimators that are (name, estimator) pairs.
    # We will pass the pipelines without fitting them first.
    estimators = []
    for name in ["RandomForest", "GradientBoosting"]:
        if name in models:
            # Use the *estimators* without the wrap of composite pipeline for stacking to work cleanly.
            # We build new pipelines because stacking will fit them internally.
            estimators.append((name.lower(), Pipeline([("prep", preprocessor), (name.lower(), models[name].named_steps[list(models[name].named_steps.keys())[-1]])])))

    # final estimator (meta-learner)
    final_estimator = RidgeCV(alphas=[0.1, 1.0, 10.0])

    if len(estimators) >= 1:
        stack = StackingRegressor(estimators=estimators, final_estimator=final_estimator, cv=5, n_jobs=-1, passthrough=False)
        # Evaluate stacking using cross-validation
        t0 = time()
        stack_res = cv_metrics(stack, X, y, cv=CV_FOLDS)
        t1 = time()
        results["Stacking"] = stack_res
        print(f"Stacking    RMSE: {stack_res['rmse_mean']:.4f} +/- {stack_res['rmse_std']:.4f} | MAE: {stack_res['mae_mean']:.4f} | R2: {stack_res['r2_mean']:.4f} | time: {t1-t0:.1f}s")
    else:
        print("Not enough base estimators for stacking; skip.")

    # Simple model selection: pick model with lowest cv RMSE
    best_name = min(results.keys(), key=lambda k: results[k]["rmse_mean"])
    print("\nCross-validated results summary:")
    pprint(results)
    print(f"\nSelected best model based on mean RMSE: {best_name}")

    # Retrain best model on full training data and save
    best_model = None
    if best_name == "Stacking":
        best_model = stack
    else:
        best_model = models[best_name]

    print("Fitting best model on full dataset...")
    best_model.fit(X, y)
    joblib.dump({"model": best_model, "features": list(X_df.columns)}, MODEL_OUT)
    print(f"Saved best model to {MODEL_OUT}")

    # Quick hold-out test to show final performance on unseen split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.15, random_state=RANDOM_STATE)
    final = clone(best_model)
    final.fit(X_train, y_train)
    y_pred = final.predict(X_test)
    rmse = mean_squared_error(y_test, y_pred, squared=False)
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    print("\nHold-out test performance (15% test):")
    print(f"RMSE: {rmse:.4f}, MAE: {mae:.4f}, R2: {r2:.4f}")

    # Example: quick feature importance for tree-based models
    print("\nIf your best model is tree-based, show feature importances:")
    try:
        # If pipeline, retrieve final estimator
        estimator = final
        if hasattr(estimator, "named_steps"):
            # Find last step (estimator)
            est = list(estimator.named_steps.values())[-1]
        else:
            est = estimator
        if hasattr(est, "feature_importances_"):
            importances = est.feature_importances_
            fi = sorted(zip(X_df.columns, importances), key=lambda x: x[1], reverse=True)[:10]
            print("Top feature importances:")
            for name, val in fi:
                print(f"  {name:30} {val:.4f}")
        else:
            print("No feature_importances_ attribute on the final estimator.")
    except Exception as e:
        print("Could not compute feature importances:", e)

    print("\nDone.")


if __name__ == "__main__":
    main()